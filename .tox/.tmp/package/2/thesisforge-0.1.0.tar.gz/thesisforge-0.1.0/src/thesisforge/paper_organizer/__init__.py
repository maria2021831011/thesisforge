"""
Paper Organizer module
- PDF handling
- Notes management
- Metadata extraction
"""
