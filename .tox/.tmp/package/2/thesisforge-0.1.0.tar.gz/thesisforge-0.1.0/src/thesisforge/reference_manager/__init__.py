"""
Reference Manager module
- BibTeX
- DOI
- Citation helpers
"""
