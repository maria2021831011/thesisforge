"""
ThesisForge: A Python toolkit for academic research and thesis management.
Modules:
- statistics
- visualization
- reference_manager
- paper_organizer
- utils
"""
__version__ = "0.1.0"
